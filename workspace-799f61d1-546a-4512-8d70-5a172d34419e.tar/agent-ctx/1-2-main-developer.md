# Task 1-2: Home Section & Teacher Section Components

## Agent: Main Developer

## Status: Completed

## Files Created
1. `/home/z/my-project/src/components/sections/home-section.tsx`
2. `/home/z/my-project/src/components/sections/teacher-section.tsx`

## Home Section (`home-section.tsx`)
- **Welcome Banner**: Dynamic greeting based on time of day (morning/afternoon/evening) with student name from `useAppStore`, grade display, and a rice stalk emoji (🌾) reflecting the rural education theme
- **Quick Stats Cards** (4-card grid, 2-col on mobile / 4-col on desktop): Total XP (Zap icon, amber), Level (Trophy icon, emerald), Streak in days (Flame icon, orange), Questions Asked (BookOpen icon, violet) — each with colored backgrounds and staggered `animate-fade-in-up` entrance
- **Quick Action Cards** (2x2 grid): "Ask AI Teacher" → teacher tab, "Scan Textbook" → scanner tab, "Take a Quiz" → quiz tab, "Career Guidance" → career tab. Each card has a gradient icon, label, and description. Hover lifts the card (`hover:-translate-y-0.5`)
- **Daily Tip Card**: Amber-themed card with Lightbulb icon. Tip is deterministically selected based on day-of-year so it changes daily. 8 unique educational tips included
- **Subject Quick-Select Chips**: Math, Science, English, Social Studies, Hindi — each with an emoji and unique pastel color. Clicking navigates to the teacher tab
- All animations use the project's existing `animate-fade-in-up` CSS class with staggered delays
- Uses shadcn/ui `Card`, `CardContent`, `Badge`, `Button` and lucide-react icons

## Teacher Section (`teacher-section.tsx`)
- **Subject Selector Bar**: Horizontal scrollable row of `Badge` components (General, Math, Science, English, Social Studies, Hindi). Active subject uses `variant="default"`, others use `variant="outline"` with hover effects
- **Chat Messages Area**: Scrollable with `custom-scrollbar` class, flex-1 for full height
  - **Empty State**: Avatar, welcome message, 6 suggestion cards (e.g., "What is photosynthesis?") that directly trigger `sendMessage` on click
  - **User Messages**: Right-aligned, primary-colored bubbles with `rounded-br-md` for a chat bubble feel, User icon avatar
  - **AI Messages**: Left-aligned, card-colored with border and shadow, `rounded-bl-md`, "V" letter avatar in primary-colored circle
  - Each message has `animate-slide-in` animation
  - **Loading State**: Shows "VidyaAI is thinking..." with Bot icon and animated bouncing dots
- **Message Input Area**: 
  - "Listen to last reply" button (Volume2 icon) that calls `POST /api/speak` with the last assistant message text, plays returned audio blob, shows Loader2 spinner while speaking
  - Microphone button: toggles MediaRecorder, shows pulsing red ring animation (`animate-pulse-ring`) and a red dot indicator while recording. On stop, converts audio to base64, sends to `POST /api/transcribe`, auto-sends the transcribed text
  - Textarea with auto-resize, Enter to send (Shift+Enter for newline), disabled during loading
  - Send button (rounded-full, primary colored, disabled when empty or loading)
- **API Integration**: 
  - `POST /api/chat` with `{ message, sessionId, language, subject, studentName, grade }`
  - `POST /api/transcribe` with `{ audio: base64string }`
  - `POST /api/speak` with `{ text }`
- Adds messages to Zustand store via `addChatMessage`, updates streaming via `updateLastAssistantMessage`, awards 5 XP per question via `updateXP(5)`

## Lint
- Initial lint had 1 error: `set-state-in-effect` for tip index in home-section. Fixed by replacing `useState` + `useEffect` with a pure `useMemo` computation. Final lint: clean, zero errors.
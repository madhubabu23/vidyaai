'use client';

import { useEffect } from 'react';
import { AppShell } from '@/components/app-shell';
import { OnboardingModal } from '@/components/onboarding-modal';
import HomeSection from '@/components/sections/home-section';
import TeacherSection from '@/components/sections/teacher-section';
import ScannerSection from '@/components/sections/scanner-section';
import QuizSection from '@/components/sections/quiz-section';
import ProgressSection from '@/components/sections/progress-section';
import CareerSection from '@/components/sections/career-section';
import { useAppStore } from '@/store/app-store';

export default function Page() {
  const { activeTab, isOnboarded, setIsOnboarded, setStudent } = useAppStore();

  // Restore session from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('vidyaai-session');
      if (saved) {
        const data = JSON.parse(saved);
        if (data.student) {
          setStudent(data.student);
          setIsOnboarded(true);
        }
      }
    } catch {
      // ignore
    }
  }, [setStudent, setIsOnboarded]);

  // Save session to localStorage
  useEffect(() => {
    if (isOnboarded && useAppStore.getState().student) {
      localStorage.setItem(
        'vidyaai-session',
        JSON.stringify({
          student: useAppStore.getState().student,
        })
      );
    }
  }, [isOnboarded, activeTab]);

  const renderSection = () => {
    switch (activeTab) {
      case 'home':
        return <HomeSection />;
      case 'teacher':
        return <TeacherSection />;
      case 'scanner':
        return <ScannerSection />;
      case 'quiz':
        return <QuizSection />;
      case 'progress':
        return <ProgressSection />;
      case 'career':
        return <CareerSection />;
      default:
        return <HomeSection />;
    }
  };

  return (
    <AppShell>
      <OnboardingModal />
      {isOnboarded && (
        <div className="animate-fade-in-up">
          {renderSection()}
        </div>
      )}
    </AppShell>
  );
}
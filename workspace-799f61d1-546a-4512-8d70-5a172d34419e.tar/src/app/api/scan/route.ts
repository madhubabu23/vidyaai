import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const { image, language = 'english', subject } = await req.json();

    if (!image) {
      return NextResponse.json({ error: 'Image is required' }, { status: 400 });
    }

    // Remove data URL prefix if present
    const base64Image = image.replace(/^data:image\/[^;]+;base64,/, '');
    const mimeType = image.includes('image/png') ? 'image/png' : 'image/jpeg';

    const langInstruction: Record<string, string> = {
      english: 'Respond in English.',
      hindi: 'Hindi mein jawab do.',
      telugu: 'Telugulo aasisthaavu.',
      tamil: 'Tamilil paarungal.',
      kannada: 'Kannadadalli beku.',
    };

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const prompt = `You are VidyaAI, a helpful educational assistant for rural students. 
You are looking at a page from a student's textbook or notebook.

1. First, carefully read and extract all the text from this image.
2. Then, explain the content in simple, easy-to-understand language.
3. Give 2-3 real-life examples that relate to village/rural life (farming, cooking, nature, daily activities).
4. If there are formulas or diagrams, explain them simply.
5. ${langInstruction[language] || langInstruction.english}

Format your response clearly with:
- **Extracted Text:** (the text from the image)
- **Simple Explanation:** (easy-to-understand explanation)
- **Real-life Examples:** (relatable examples)
- **Key Points to Remember:** (summary bullets)`;

    const response = await zai.chat.completions.createVision({
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            {
              type: 'image_url',
              image_url: {
                url: `data:${mimeType};base64,${base64Image}`
              }
            }
          ]
        }
      ],
      thinking: { type: 'disabled' }
    });

    const explanation = response.choices[0]?.message?.content || 'Could not analyze this image. Please try with a clearer photo.';

    // Save to database
    try {
      const studentId = req.headers.get('x-student-id');
      if (studentId && studentId !== 'default') {
        await db.scanHistory.create({
          data: {
            studentId,
            imageData: 'base64_uploaded',
            extractedText: 'Textbook page scanned',
            explanation,
            subject: subject || null,
          }
        });
        await db.student.update({
          where: { id: studentId },
          data: {
            xp: { increment: 15 },
            lastActive: new Date(),
          }
        });
      }
    } catch (dbError) {
      console.log('DB save skipped:', dbError);
    }

    return NextResponse.json({ explanation });
  } catch (error) {
    console.error('Scan API Error:', error);
    return NextResponse.json(
      { error: 'Could not scan the image. Please try again.' },
      { status: 500 }
    );
  }
}
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const { name, grade, language = 'english' } = await req.json();

    if (!name) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 });
    }

    // Check if student already exists (by name for demo)
    let student = await db.student.findFirst({ where: { name } });

    if (!student) {
      student = await db.student.create({
        data: { name, grade: grade || '10', language }
      });
    }

    // Get badges
    const earnedBadges = await db.studentBadge.findMany({
      where: { studentId: student.id },
      include: { badge: true },
      orderBy: { earnedAt: 'desc' }
    });

    return NextResponse.json({
      id: student.id,
      name: student.name,
      grade: student.grade,
      language: student.language,
      xp: student.xp,
      level: student.level,
      streak: student.streak,
      badges: earnedBadges.map(sb => ({
        id: sb.badge.id,
        name: sb.badge.name,
        icon: sb.badge.icon,
        description: sb.badge.description,
        earnedAt: sb.earnedAt,
      })),
    });
  } catch (error) {
    console.error('Student API Error:', error);
    return NextResponse.json({ error: 'Failed to create/get student' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Student ID is required' }, { status: 400 });
    }

    const student = await db.student.findUnique({
      where: { id },
      include: {
        badges: { include: { badge: true }, orderBy: { earnedAt: 'desc' } }
      }
    });

    if (!student) {
      return NextResponse.json({ error: 'Student not found' }, { status: 404 });
    }

    return NextResponse.json({
      id: student.id,
      name: student.name,
      grade: student.grade,
      language: student.language,
      xp: student.xp,
      level: student.level,
      streak: student.streak,
      badges: student.badges.map(sb => ({
        id: sb.badge.id,
        name: sb.badge.name,
        icon: sb.badge.icon,
        description: sb.badge.description,
        earnedAt: sb.earnedAt,
      })),
    });
  } catch (error) {
    console.error('Student GET API Error:', error);
    return NextResponse.json({ error: 'Failed to fetch student' }, { status: 500 });
  }
}
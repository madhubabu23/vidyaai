import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { interest, language = 'english', grade = '10' } = await req.json();

    if (!interest) {
      return NextResponse.json({ error: 'Interest is required' }, { status: 400 });
    }

    const langInstructions: Record<string, string> = {
      english: 'Respond in English.',
      hindi: 'Hindi mein jawab do.',
      telugu: 'Telugulo aasisthaavu.',
      tamil: 'Tamilil paarungal.',
      kannada: 'Kannadadalli beku.',
    };

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const prompt = `You are a career guidance counselor for rural Indian students. A student in class ${grade} is interested in "${interest}".

${langInstructions[language] || langInstructions.english}

Provide a comprehensive but simple career guidance covering:

1. **Career Options:** List 3-5 specific career paths related to their interest, including:
   - What the career involves
   - Education needed
   - Average salary range
   - Job availability in India

2. **After 10th/12th Options:** What courses or streams they should choose

3. **Scholarships:** Mention 2-3 relevant government or private scholarships:
   - Scholarship name
   - Eligibility
   - How to apply

4. **Government Schemes:** Mention 2-3 relevant government education schemes for rural students

5. **Skill Development:** Recommend free or low-cost ways to build skills:
   - Online platforms (free ones)
   - Government training centers
   - Local opportunities

6. **Success Story:** Share an inspiring real story of someone from a rural background who succeeded in a related field

Format the response with clear headings and bullet points. Keep language simple and encouraging.`;

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'You are a compassionate and knowledgeable career counselor specializing in guiding rural Indian students.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      thinking: { type: 'disabled' }
    });

    const guidance = completion.choices[0]?.message?.content || 'Could not generate career guidance. Please try again.';

    return NextResponse.json({ guidance });
  } catch (error) {
    console.error('Career API Error:', error);
    return NextResponse.json(
      { error: 'Failed to get career guidance. Please try again.' },
      { status: 500 }
    );
  }
}
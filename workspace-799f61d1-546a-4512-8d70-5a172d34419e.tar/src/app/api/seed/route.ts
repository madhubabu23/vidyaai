import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    // Seed badges
    const badges = [
      { name: 'First Question', description: 'Asked your first question to AI Teacher', icon: '💬', xpReward: 10, category: 'chat' },
      { name: 'Curious Mind', description: 'Asked 10 questions', icon: '🧠', xpReward: 25, category: 'chat' },
      { name: 'Quiz Master', description: 'Scored 100% on a quiz', icon: '🏆', xpReward: 50, category: 'quiz' },
      { name: 'Bookworm', description: 'Scanned your first textbook page', icon: '📖', xpReward: 15, category: 'scanner' },
      { name: 'Explorer', description: 'Explored career guidance', icon: '🚀', xpReward: 10, category: 'career' },
      { name: 'Streak Star', description: 'Maintained a 3-day learning streak', icon: '🔥', xpReward: 30, category: 'streak' },
      { name: 'Multilingual', description: 'Switched to a regional language', icon: '🌍', xpReward: 15, category: 'chat' },
      { name: 'Quick Learner', description: 'Completed 5 quizzes', icon: '⚡', xpReward: 40, category: 'quiz' },
      { name: 'Voice Learner', description: 'Used voice to ask a question', icon: '🎤', xpReward: 15, category: 'chat' },
      { name: 'Scholar', description: 'Reached Level 5', icon: '🎓', xpReward: 100, category: 'chat' },
    ];

    for (const badge of badges) {
      await db.badge.upsert({
        where: { id: `badge-${badge.name.toLowerCase().replace(/\s+/g, '-')}` },
        create: { id: `badge-${badge.name.toLowerCase().replace(/\s+/g, '-')}`, ...badge },
        update: {},
      });
    }

    return NextResponse.json({ success: true, message: 'Badges seeded successfully' });
  } catch (error) {
    console.error('Seed Error:', error);
    return NextResponse.json({ error: 'Failed to seed' }, { status: 500 });
  }
}
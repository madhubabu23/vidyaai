import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { audio } = await req.json();

    if (!audio) {
      return NextResponse.json({ error: 'Audio data is required' }, { status: 400 });
    }

    // Remove the data URL prefix if present
    const base64Audio = audio.replace(/^data:audio\/[^;]+;base64,/, '');

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const response = await zai.audio.asr.create({
      file_base64: base64Audio
    });

    const transcription = response.text || '';

    return NextResponse.json({ text: transcription });
  } catch (error) {
    console.error('ASR API Error:', error);
    return NextResponse.json(
      { error: 'Could not understand audio. Please try again.' },
      { status: 500 }
    );
  }
}
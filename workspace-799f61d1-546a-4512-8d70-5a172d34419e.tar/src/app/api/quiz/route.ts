import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const languageInstructions: Record<string, string> = {
  english: 'Create the quiz in English.',
  hindi: 'Hindi mein quiz banavo.',
  telugu: 'Telugulo quiz racu.',
  tamil: 'Tamilil quiz seidhu kudu.',
  kannada: 'Kannadadalli quiz hagu.',
};

export async function POST(req: NextRequest) {
  try {
    const { topic, subject, difficulty = 'medium', language = 'english', numQuestions = 5, studentId } = await req.json();

    if (!topic || !subject) {
      return NextResponse.json({ error: 'Topic and subject are required' }, { status: 400 });
    }

    const langInst = languageInstructions[language] || languageInstructions.english;

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const prompt = `Create a ${difficulty} difficulty quiz about "${topic}" in ${subject} for a rural Indian student.

${langInst}

Create exactly ${numQuestions} multiple choice questions.
For each question, provide 4 options (A, B, C, D).
Make the questions relatable to village/rural life where possible.

IMPORTANT: Respond with ONLY valid JSON in this exact format, no other text:
{
  "questions": [
    {
      "question": "The question text here?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctIndex": 0,
      "explanation": "Simple explanation of why this is the correct answer, using a real-life example."
    }
  ]
}`;

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: 'You are an expert quiz creator for educational content. Always respond with valid JSON only.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      thinking: { type: 'disabled' }
    });

    const raw = completion.choices[0]?.message?.content || '';

    // Try to parse JSON from the response
    let quizData;
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      quizData = JSON.parse(jsonMatch ? jsonMatch[0] : raw);
    } catch {
      return NextResponse.json(
        { error: 'Failed to generate quiz. Please try again.' },
        { status: 500 }
      );
    }

    const questions = (quizData.questions || []).map((q: { question: string; options: string[]; correctIndex: number; explanation: string }, i: number) => ({
      id: `q-${i}`,
      question: q.question,
      options: q.options,
      correctIndex: q.correctIndex,
      explanation: q.explanation,
    }));

    // Save quiz attempt placeholder
    try {
      if (studentId) {
        await db.quizAttempt.create({
          data: {
            studentId,
            subject,
            topic,
            questions: JSON.stringify(questions),
            answers: '[]',
            score: 0,
            total: questions.length,
          }
        });
      }
    } catch (dbError) {
      console.log('DB save skipped:', dbError);
    }

    return NextResponse.json({ questions });
  } catch (error) {
    console.error('Quiz API Error:', error);
    return NextResponse.json(
      { error: 'Failed to generate quiz. Please try again.' },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { studentId, quizData, score, total, subject, topic } = await req.json();

    if (!studentId || !quizData) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Update quiz attempt
    const latestAttempt = await db.quizAttempt.findFirst({
      where: { studentId, subject, topic },
      orderBy: { createdAt: 'desc' }
    });

    if (latestAttempt) {
      await db.quizAttempt.update({
        where: { id: latestAttempt.id },
        data: { answers: JSON.stringify(quizData.answers), score, total }
      });
    }

    // Update student XP (+20 per quiz, +10 bonus per correct answer)
    const xpGain = 20 + (score * 10);
    await db.student.update({
      where: { id: studentId },
      data: {
        xp: { increment: xpGain },
        lastActive: new Date(),
      }
    });

    // Update learning progress
    const progress = await db.learningProgress.upsert({
      where: {
        studentId_subject_topic: { studentId, subject, topic }
      },
      create: {
        studentId,
        subject,
        topic,
        score,
        attempts: 1,
        mastered: score === total,
        lastStudied: new Date(),
      },
      update: {
        score: Math.max(score, 0),
        attempts: { increment: 1 },
        mastered: score >= total * 0.8,
        lastStudied: new Date(),
      }
    });

    return NextResponse.json({
      success: true,
      xpGain,
      progress,
      newTotal: (await db.student.findUnique({ where: { id: studentId } }))?.xp || 0,
    });
  } catch (error) {
    console.error('Quiz update API Error:', error);
    return NextResponse.json({ error: 'Failed to save quiz results' }, { status: 500 });
  }
}
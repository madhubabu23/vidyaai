import { NextRequest, NextResponse } from 'next/server';

function splitTextIntoChunks(text: string, maxLength = 950) {
  const chunks: string[] = [];
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];

  let currentChunk = '';
  for (const sentence of sentences) {
    if ((currentChunk + sentence).length <= maxLength) {
      currentChunk += sentence;
    } else {
      if (currentChunk) chunks.push(currentChunk.trim());
      // If single sentence is too long, split by comma
      if (sentence.length > maxLength) {
        const parts = sentence.split(/[,;:]/);
        let subChunk = '';
        for (const part of parts) {
          if ((subChunk + part).length <= maxLength) {
            subChunk += part + ',';
          } else {
            if (subChunk) chunks.push(subChunk.trim());
            subChunk = part + ',';
          }
        }
        if (subChunk) currentChunk = subChunk;
      } else {
        currentChunk = sentence;
      }
    }
  }
  if (currentChunk) chunks.push(currentChunk.trim());
  return chunks;
}

export async function POST(req: NextRequest) {
  try {
    const { text, speed = 1.0 } = await req.json();

    if (!text || text.trim().length === 0) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const trimmedText = text.trim();
    const chunks = splitTextIntoChunks(trimmedText);

    if (chunks.length === 0) {
      return NextResponse.json({ error: 'No valid text to speak' }, { status: 400 });
    }

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    // Generate audio for the first chunk (most common use case - short answers)
    const firstChunk = chunks[0].substring(0, 1024);
    const clampedSpeed = Math.max(0.5, Math.min(2.0, speed));

    const response = await zai.audio.tts.create({
      input: firstChunk,
      voice: 'tongtong',
      speed: clampedSpeed,
      response_format: 'wav',
      stream: false
    });

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(new Uint8Array(arrayBuffer));

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'audio/wav',
        'Content-Length': buffer.length.toString(),
        'Cache-Control': 'no-cache',
      },
    });
  } catch (error) {
    console.error('TTS API Error:', error);
    return NextResponse.json(
      { error: 'Could not generate speech. Please try again.' },
      { status: 500 }
    );
  }
}
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const conversations = new Map<string, { role: string; content: string }[]>();

const languagePrompts: Record<string, string> = {
  english: 'Respond in English.',
  hindi: 'Hindi mein jawab do. Devanagari script use karo.',
  telugu: 'Telugulo aasisthaavu. Telugu script use cheyyandi.',
  tamil: 'Tamilil paarungal. Tamil script use pannunga.',
  kannada: 'Kannadadalli beku. Kannada script use madi.',
};

export async function POST(req: NextRequest) {
  try {
    const { message, sessionId = 'default', language = 'english', subject, studentName, grade } = await req.json();

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    const langInstruction = languagePrompts[language] || languagePrompts.english;

    const systemPrompt = `You are VidyaAI, a friendly and patient AI teacher for rural students in India. 

Your teaching approach:
- Explain concepts using simple, everyday examples from village/rural life (farming, cooking, nature, local markets)
- Be warm, encouraging, and never condescending
- Break down complex topics into small, digestible pieces
- Use short sentences and simple vocabulary
- If a student seems confused, try a different explanation approach
- Celebrate their effort and curiosity
- ${langInstruction}

Student info: Name: ${studentName || 'Student'}, Grade: ${grade || '10th'}
${subject ? `Subject: ${subject}` : ''}

Remember: You are helping students who may not have access to good teachers. Be their patient, caring mentor.`;

    let history = conversations.get(sessionId) || [
      { role: 'assistant', content: systemPrompt }
    ];

    // Add user message
    history.push({ role: 'user', content: message });

    // Trim history to keep last 20 messages (including system prompt)
    if (history.length > 20) {
      history = [history[0], ...history.slice(-19)];
    }

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const completion = await zai.chat.completions.create({
      messages: history.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content })),
      thinking: { type: 'disabled' }
    });

    const aiResponse = completion.choices[0]?.message?.content || 'Sorry, I could not understand. Please try again.';

    // Add AI response to history
    history.push({ role: 'assistant', content: aiResponse });
    conversations.set(sessionId, history);

    // Save to database if student exists
    try {
      if (sessionId !== 'default') {
        await db.chatMessage.create({
          data: {
            studentId: sessionId,
            role: 'user',
            content: message,
            subject: subject || null,
          }
        });
        await db.chatMessage.create({
          data: {
            studentId: sessionId,
            role: 'assistant',
            content: aiResponse,
            subject: subject || null,
          }
        });

        // Update student XP (+5 per question)
        await db.student.update({
          where: { id: sessionId },
          data: {
            xp: { increment: 5 },
            lastActive: new Date(),
          }
        });
      }
    } catch (dbError) {
      // DB save is non-critical
      console.log('DB save skipped:', dbError);
    }

    return NextResponse.json({ response: aiResponse });
  } catch (error) {
    console.error('Chat API Error:', error);
    return NextResponse.json(
      { error: 'Failed to get response. Please try again.' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get('sessionId') || 'default';
  conversations.delete(sessionId);
  return NextResponse.json({ success: true });
}
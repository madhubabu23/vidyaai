import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const studentId = searchParams.get('studentId');

    if (!studentId) {
      return NextResponse.json({ error: 'Student ID is required' }, { status: 400 });
    }

    // Get student with badges
    const student = await db.student.findUnique({
      where: { id: studentId },
      include: {
        badges: { include: { badge: true }, orderBy: { earnedAt: 'desc' } },
        progress: { orderBy: { lastStudied: 'asc' } },
        quizAttempts: { orderBy: { createdAt: 'desc' }, take: 20 },
      }
    });

    if (!student) {
      return NextResponse.json({ error: 'Student not found' }, { status: 404 });
    }

    // Calculate subject-wise stats
    const subjectStats: Record<string, { total: number; score: number; quizzes: number }> = {};
    student.quizAttempts.forEach(attempt => {
      if (!subjectStats[attempt.subject]) {
        subjectStats[attempt.subject] = { total: 0, score: 0, quizzes: 0 };
      }
      subjectStats[attempt.subject].total += attempt.total;
      subjectStats[attempt.subject].score += attempt.score;
      subjectStats[attempt.subject].quizzes++;
    });

    const subjectPerformance = Object.entries(subjectStats).map(([subject, stats]) => ({
      subject,
      ...stats,
      average: stats.total > 0 ? Math.round((stats.score / stats.total) * 100) : 0,
    }));

    // Calculate daily activity for the last 7 days
    const dailyActivity = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);

      const chatCount = await db.chatMessage.count({
        where: {
          studentId,
          role: 'user',
          createdAt: { gte: date, lt: nextDate }
        }
      });
      const quizCount = await db.quizAttempt.count({
        where: {
          studentId,
          createdAt: { gte: date, lt: nextDate }
        }
      });

      dailyActivity.push({
        date: date.toISOString().split('T')[0],
        day: date.toLocaleDateString('en', { weekday: 'short' }),
        questions: chatCount,
        quizzes: quizCount,
      });
    }

    return NextResponse.json({
      student: {
        id: student.id,
        name: student.name,
        grade: student.grade,
        language: student.language,
        xp: student.xp,
        level: student.level,
        streak: student.streak,
        lastActive: student.lastActive,
      },
      badges: student.badges.map(sb => ({
        id: sb.badge.id,
        name: sb.badge.name,
        icon: sb.badge.icon,
        description: sb.badge.description,
        earnedAt: sb.earnedAt,
      })),
      progress: student.progress,
      subjectPerformance,
      totalQuizzes: student.quizAttempts.length,
      totalQuestions: await db.chatMessage.count({ where: { studentId, role: 'user' } }),
      dailyActivity,
    });
  } catch (error) {
    console.error('Progress API Error:', error);
    return NextResponse.json({ error: 'Failed to fetch progress' }, { status: 500 });
  }
}
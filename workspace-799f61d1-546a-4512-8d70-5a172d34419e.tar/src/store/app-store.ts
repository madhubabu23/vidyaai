import { create } from 'zustand';

export type Language = 'english' | 'hindi' | 'telugu' | 'tamil' | 'kannada';
export type AppTab = 'home' | 'teacher' | 'scanner' | 'quiz' | 'progress' | 'career';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  subject?: string;
  timestamp: Date;
  isStreaming?: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  userAnswer?: number;
}

export interface QuizState {
  questions: QuizQuestion[];
  currentQuestion: number;
  answers: (number | null)[];
  isCompleted: boolean;
  score: number;
  subject: string;
  topic: string;
}

export interface StudentState {
  id: string;
  name: string;
  grade: string;
  language: Language;
  xp: number;
  level: number;
  streak: number;
  badges: { id: string; name: string; icon: string; description: string; earnedAt: string }[];
}

interface AppState {
  // Navigation
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;

  // Student
  student: StudentState | null;
  setStudent: (student: StudentState) => void;
  updateXP: (amount: number) => void;

  // Language
  language: Language;
  setLanguage: (lang: Language) => void;

  // Chat
  chatMessages: ChatMessage[];
  addChatMessage: (msg: ChatMessage) => void;
  updateLastAssistantMessage: (content: string) => void;
  clearChat: () => void;

  // Quiz
  quiz: QuizState | null;
  setQuiz: (quiz: QuizState) => void;
  setQuizAnswer: (questionIndex: number, answer: number) => void;
  completeQuiz: () => void;
  resetQuiz: () => void;

  // Scanner
  scannedImage: string | null;
  scanResult: string | null;
  isScanning: boolean;
  setScannedImage: (img: string | null) => void;
  setScanResult: (result: string | null) => void;
  setIsScanning: (scanning: boolean) => void;

  // Voice
  isRecording: boolean;
  setIsRecording: (recording: boolean) => void;
  isSpeaking: boolean;
  setIsSpeaking: (speaking: boolean) => void;

  // Career
  careerInterest: string;
  setCareerInterest: (interest: string) => void;
  careerResults: string | null;
  setCareerResults: (results: string | null) => void;

  // Onboarding
  isOnboarded: boolean;
  setIsOnboarded: (onboarded: boolean) => void;
}

export const useAppStore = create<AppState>((set) => ({
  // Navigation
  activeTab: 'home',
  setActiveTab: (tab) => set({ activeTab: tab }),

  // Student
  student: null,
  setStudent: (student) => set({ student }),
  updateXP: (amount) =>
    set((state) => {
      if (!state.student) return state;
      const newXp = state.student.xp + amount;
      const newLevel = Math.floor(newXp / 100) + 1;
      return {
        student: {
          ...state.student,
          xp: newXp,
          level: newLevel,
        },
      };
    }),

  // Language
  language: 'english',
  setLanguage: (lang) => set({ language: lang }),

  // Chat
  chatMessages: [],
  addChatMessage: (msg) =>
    set((state) => ({ chatMessages: [...state.chatMessages, msg] })),
  updateLastAssistantMessage: (content) =>
    set((state) => {
      const msgs = [...state.chatMessages];
      const lastIdx = msgs.findLastIndex((m) => m.role === 'assistant');
      if (lastIdx >= 0) {
        msgs[lastIdx] = { ...msgs[lastIdx], content, isStreaming: false };
      }
      return { chatMessages: msgs };
    }),
  clearChat: () => set({ chatMessages: [] }),

  // Quiz
  quiz: null,
  setQuiz: (quiz) => set({ quiz }),
  setQuizAnswer: (questionIndex, answer) =>
    set((state) => {
      if (!state.quiz) return state;
      const newAnswers = [...state.quiz.answers];
      newAnswers[questionIndex] = answer;
      return { quiz: { ...state.quiz, answers: newAnswers } };
    }),
  completeQuiz: () =>
    set((state) => {
      if (!state.quiz) return state;
      let score = 0;
      state.quiz.questions.forEach((q, i) => {
        if (state.quiz!.answers[i] === q.correctIndex) score++;
      });
      return { quiz: { ...state.quiz, isCompleted: true, score } };
    }),
  resetQuiz: () => set({ quiz: null }),

  // Scanner
  scannedImage: null,
  scanResult: null,
  isScanning: false,
  setScannedImage: (img) => set({ scannedImage: img }),
  setScanResult: (result) => set({ scanResult: result }),
  setIsScanning: (scanning) => set({ isScanning: scanning }),

  // Voice
  isRecording: false,
  setIsRecording: (recording) => set({ isRecording: recording }),
  isSpeaking: false,
  setIsSpeaking: (speaking) => set({ isSpeaking: speaking }),

  // Career
  careerInterest: '',
  setCareerInterest: (interest) => set({ careerInterest: interest }),
  careerResults: null,
  setCareerResults: (results) => set({ careerResults: results }),

  // Onboarding
  isOnboarded: false,
  setIsOnboarded: (onboarded) => set({ isOnboarded: onboarded }),
}));
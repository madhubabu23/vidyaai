'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAppStore, type Language } from '@/store/app-store';
import { GraduationCap, Sparkles, User } from 'lucide-react';
import { motion } from 'framer-motion';

export function OnboardingModal() {
  const { isOnboarded, setIsOnboarded, setStudent, setLanguage } = useAppStore();
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('10');
  const [language, setLang] = useState<Language>('english');
  const [isLoading, setIsLoading] = useState(false);

  const handleComplete = () => {
    if (!name.trim()) return;
    setIsLoading(true);

    // Set student state immediately (client-side)
    const localId = 'local-' + Date.now();
    setStudent({
      id: localId,
      name: name.trim(),
      grade,
      language,
      xp: 0,
      level: 1,
      streak: 0,
      badges: [],
    });
    setLanguage(language);
    setIsOnboarded(true);
    setIsLoading(false);

    // Sync to server in background (non-blocking)
    fetch('/api/student', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name.trim(), grade, language }),
    }).then(res => res.json()).then(student => {
      if (student?.id) {
        setStudent({
          id: student.id,
          name: student.name,
          grade: student.grade,
          language: student.language,
          xp: student.xp || 0,
          level: student.level || 1,
          streak: student.streak || 0,
          badges: student.badges || [],
        });
      }
      return fetch('/api/seed', { method: 'POST' });
    }).catch(() => {
      // Silent fail - already using local state
    });
  };

  return (
    <Dialog open={!isOnboarded} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md border-2 border-primary/20" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <GraduationCap className="h-8 w-8 text-primary" />
          </div>
          <DialogTitle className="text-2xl font-bold">Welcome to VidyaAI!</DialogTitle>
          <DialogDescription className="text-base">
            Your personal AI teacher. Let&apos;s set up your profile to get started.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium">
              Your Name
            </Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="name"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10"
                onKeyDown={(e) => e.key === 'Enter' && handleComplete()}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Your Class/Grade</Label>
            <Select value={grade} onValueChange={setGrade}>
              <SelectTrigger>
                <SelectValue placeholder="Select grade" />
              </SelectTrigger>
              <SelectContent>
                {[...Array(12)].map((_, i) => (
                  <SelectItem key={i + 1} value={String(i + 1)}>
                    Class {i + 1}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-medium">Preferred Language</Label>
            <Select value={language} onValueChange={(v) => setLang(v as Language)}>
              <SelectTrigger>
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="english">English</SelectItem>
                <SelectItem value="hindi">हिन्दी (Hindi)</SelectItem>
                <SelectItem value="telugu">తెలుగు (Telugu)</SelectItem>
                <SelectItem value="tamil">தமிழ் (Tamil)</SelectItem>
                <SelectItem value="kannada">ಕನ್ನಡ (Kannada)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <motion.div whileTap={{ scale: 0.98 }}>
            <Button
              className="w-full mt-2 h-12 text-base font-semibold"
              onClick={handleComplete}
              disabled={!name.trim() || isLoading}
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                  Setting up...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Start Learning
                </span>
              )}
            </Button>
          </motion.div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
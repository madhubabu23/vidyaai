'use client';

import { useAppStore, type AppTab } from '@/store/app-store';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Home,
  MessageCircle,
  Camera,
  FileQuestion,
  BarChart3,
  Compass,
  Star,
  Sparkles,
  Menu,
  X,
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';

const navItems: { id: AppTab; label: string; icon: React.ElementType }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'teacher', label: 'AI Teacher', icon: MessageCircle },
  { id: 'scanner', label: 'Scan Book', icon: Camera },
  { id: 'quiz', label: 'Take Quiz', icon: FileQuestion },
  { id: 'progress', label: 'Progress', icon: BarChart3 },
  { id: 'career', label: 'Careers', icon: Compass },
];

function XPBar({ compact = false }: { compact?: boolean }) {
  const { student } = useAppStore();
  if (!student) return null;

  const xpForNextLevel = 100;
  const currentLevelXP = student.xp % 100;
  const progressPercent = (currentLevelXP / xpForNextLevel) * 100;

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 text-xs font-medium">
          <Sparkles className="h-3 w-3 text-amber-500" />
          <span>Lv.{student.level}</span>
        </div>
        <Progress value={progressPercent} className="h-1.5 w-16" />
        <span className="text-xs text-muted-foreground">{student.xp} XP</span>
      </div>
    );
  }

  return (
    <div className="space-y-2 p-4 rounded-xl bg-primary/5 border border-primary/10">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
            <Star className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="text-sm font-semibold">Level {student.level}</p>
            <p className="text-xs text-muted-foreground">{student.xp} / {student.level * 100} XP</p>
          </div>
        </div>
        {student.streak > 0 && (
          <Badge variant="secondary" className="bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400">
            🔥 {student.streak} day streak
          </Badge>
        )}
      </div>
      <Progress value={progressPercent} className="h-2" />
    </div>
  );
}

function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const { activeTab, setActiveTab, student } = useAppStore();

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-4 pb-2">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold text-lg">
            V
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">VidyaAI</h1>
            <p className="text-xs text-muted-foreground">Your AI Teacher</p>
          </div>
        </div>
      </div>

      <Separator className="my-2" />

      {/* Student Info */}
      {student && (
        <div className="px-4 pb-3">
          <XPBar />
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <Button
              key={item.id}
              variant={isActive ? 'secondary' : 'ghost'}
              className={cn(
                'w-full justify-start gap-3 h-11 font-medium transition-all',
                isActive && 'bg-primary/10 text-primary hover:bg-primary/15'
              )}
              onClick={() => {
                setActiveTab(item.id);
                onNavigate?.();
              }}
            >
              <Icon className={cn('h-5 w-5', isActive && 'text-primary')} />
              {item.label}
            </Button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold text-sm">
            {student?.name?.charAt(0)?.toUpperCase() || 'S'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{student?.name || 'Student'}</p>
            <p className="text-xs text-muted-foreground">Class {student?.grade || '10'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Mobile Bottom Navigation
function MobileBottomNav() {
  const { activeTab, setActiveTab, student } = useAppStore();
  const mobileItems = navItems.slice(0, 5);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-t md:hidden safe-area-inset-bottom">
      <div className="flex items-center justify-around h-16 px-2">
        {mobileItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                'flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg transition-all min-w-0',
                isActive ? 'text-primary' : 'text-muted-foreground'
              )}
            >
              <Icon className={cn('h-5 w-5', isActive && 'drop-shadow-sm')} />
              <span className="text-[10px] font-medium truncate max-w-14">{item.label}</span>
            </button>
          );
        })}
        <Sheet>
          <SheetTrigger asChild>
            <button className="flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg text-muted-foreground min-w-0">
              <Menu className="h-5 w-5" />
              <span className="text-[10px] font-medium">More</span>
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="rounded-t-2xl h-auto max-h-[60vh]">
            <SheetTitle className="sr-only">More options</SheetTitle>
            <div className="py-4">
              {student && <XPBar />}
              <div className="mt-4 space-y-2">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.id}
                      variant={activeTab === item.id ? 'secondary' : 'ghost'}
                      className="w-full justify-start gap-3"
                      onClick={() => setActiveTab(item.id)}
                    >
                      <Icon className="h-5 w-5" />
                      {item.label}
                    </Button>
                  );
                })}
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { activeTab, setActiveTab } = useAppStore();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 border-r bg-card z-40">
        <SidebarNav />
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 pb-20 md:pb-0">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <MobileBottomNav />
    </div>
  );
}
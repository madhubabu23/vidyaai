'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { useAppStore, type ChatMessage } from '@/store/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Mic, MicOff, Volume2, Loader2, Bot, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const SUBJECTS = ['General', 'Math', 'Science', 'English', 'Social Studies', 'Hindi'] as const;

const SUGGESTIONS = [
  'What is photosynthesis?',
  'Explain fractions with examples',
  'What is the water cycle?',
  'How do tenses work in English?',
  'Explain the solar system',
  'What are integers?',
];

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export default function TeacherSection() {
  const {
    student,
    chatMessages,
    addChatMessage,
    updateLastAssistantMessage,
    updateXP,
    language,
    isRecording,
    setIsRecording,
    isSpeaking,
    setIsSpeaking,
  } = useAppStore();

  const [input, setInput] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('General');
  const [isLoading, setIsLoading] = useState(false);
  const [lastAssistantAudioUrl, setLastAssistantAudioUrl] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const studentName = student?.name ?? 'Student';
  const grade = student?.grade ?? '';
  const studentId = student?.id ?? 'anonymous';

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isLoading]);

  // Cleanup audio URL on unmount
  useEffect(() => {
    return () => {
      if (lastAssistantAudioUrl) {
        URL.revokeObjectURL(lastAssistantAudioUrl);
      }
    };
  }, [lastAssistantAudioUrl]);

  const sendMessage = useCallback(
    async (messageText: string) => {
      const trimmed = messageText.trim();
      if (!trimmed || isLoading) return;

      // Add user message
      const userMsg: ChatMessage = {
        id: generateId(),
        role: 'user',
        content: trimmed,
        subject: selectedSubject === 'General' ? undefined : selectedSubject,
        timestamp: new Date(),
      };
      addChatMessage(userMsg);
      setInput('');
      setIsLoading(true);

      // Add placeholder assistant message
      const assistantMsg: ChatMessage = {
        id: generateId(),
        role: 'assistant',
        content: '',
        subject: selectedSubject === 'General' ? undefined : selectedSubject,
        timestamp: new Date(),
        isStreaming: true,
      };
      addChatMessage(assistantMsg);

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: trimmed,
            sessionId: studentId,
            language,
            subject: selectedSubject,
            studentName,
            grade,
          }),
        });

        if (!res.ok) throw new Error('Failed to get response');

        const data = await res.json();
        const reply = data.response || data.message || 'Sorry, I could not understand that. Please try again.';

        updateLastAssistantMessage(reply);
        updateXP(5);
      } catch {
        updateLastAssistantMessage(
          'Sorry, I am having trouble right now. Please check your internet connection and try again.'
        );
      } finally {
        setIsLoading(false);
      }
    },
    [isLoading, selectedSubject, addChatMessage, updateLastAssistantMessage, updateXP, studentId, language, studentName, grade]
  );

  const handleSend = () => {
    sendMessage(input);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Voice recording
  const toggleRecording = useCallback(async () => {
    if (isRecording) {
      // Stop recording
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop());

        if (audioChunksRef.current.length === 0) return;

        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();

        reader.onloadend = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          if (!base64Audio) return;

          try {
            const res = await fetch('/api/transcribe', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ audio: base64Audio }),
            });

            if (!res.ok) throw new Error('Transcription failed');

            const data = await res.json();
            const transcribedText = data.text || data.transcription || '';
            if (transcribedText) {
              setInput(transcribedText);
              // Auto-send after transcription
              sendMessage(transcribedText);
            }
          } catch {
            // Silently fail - user can type instead
          }
        };

        reader.readAsDataURL(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch {
      // Microphone not available
    }
  }, [isRecording, setIsRecording, sendMessage]);

  // TTS: Speak the last assistant message
  const speakLastMessage = useCallback(async () => {
    if (isSpeaking) return;

    const lastAssistantMsg = [...chatMessages].reverse().find((m) => m.role === 'assistant' && m.content);
    if (!lastAssistantMsg) return;

    setIsSpeaking(true);

    try {
      const res = await fetch('/api/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: lastAssistantMsg.content }),
      });

      if (!res.ok) throw new Error('TTS failed');

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setLastAssistantAudioUrl(url);

      const audio = new Audio(url);
      audio.onended = () => {
        setIsSpeaking(false);
      };
      audio.onerror = () => {
        setIsSpeaking(false);
      };
      audio.play();
    } catch {
      setIsSpeaking(false);
    }
  }, [chatMessages, isSpeaking, setIsSpeaking]);

  const lastAssistantMsg = [...chatMessages].reverse().find((m) => m.role === 'assistant' && m.content);

  return (
    <div className="flex h-full flex-col">
      {/* Subject Selector Bar */}
      <div className="shrink-0 border-b bg-card/80 backdrop-blur-sm px-3 py-2.5 md:px-4">
        <div className="custom-scrollbar flex gap-2 overflow-x-auto pb-0.5">
          {SUBJECTS.map((subject) => (
            <Badge
              key={subject}
              variant={selectedSubject === subject ? 'default' : 'outline'}
              className={cn(
                'cursor-pointer select-none whitespace-nowrap rounded-full px-3.5 py-1 text-xs font-medium transition-all duration-150',
                selectedSubject === subject
                  ? 'shadow-sm'
                  : 'hover:bg-primary/10 hover:text-primary hover:border-primary/30'
              )}
              onClick={() => setSelectedSubject(subject)}
            >
              {subject}
            </Badge>
          ))}
        </div>
      </div>

      {/* Chat Messages Area */}
      <div className="custom-scrollbar flex-1 overflow-y-auto px-3 py-4 md:px-4">
        {chatMessages.length === 0 ? (
          /* Empty State */
          <div className="flex h-full min-h-[60vh] flex-col items-center justify-center text-center px-4">
            <div className="animate-fade-in-up flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-3xl mb-4">
              🎓
            </div>
            <h2 className="animate-fade-in-up text-lg font-semibold" style={{ animationDelay: '80ms', animationFillMode: 'both' }}>
              Hi {studentName}! I&apos;m VidyaAI
            </h2>
            <p className="animate-fade-in-up mt-1 text-sm text-muted-foreground max-w-sm" style={{ animationDelay: '160ms', animationFillMode: 'both' }}>
              Ask me anything about your subjects. I&apos;ll explain in a way that&apos;s easy to understand.
            </p>
            <div className="animate-fade-in-up mt-6 grid w-full max-w-md gap-2" style={{ animationDelay: '240ms', animationFillMode: 'both' }}>
              <p className="mb-1 text-xs font-medium text-muted-foreground">Try asking:</p>
              {SUGGESTIONS.map((suggestion, i) => (
                <Card
                  key={i}
                  className="cursor-pointer border-primary/15 bg-primary/5 hover:bg-primary/10 transition-colors gap-0 py-0 shadow-none"
                  onClick={() => sendMessage(suggestion)}
                >
                  <CardContent className="flex items-center gap-2.5 p-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                      {i + 1}
                    </span>
                    <span className="text-sm text-foreground/80">{suggestion}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          /* Messages */
          <div className="space-y-4">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  'animate-slide-in flex gap-2.5',
                  msg.role === 'user' ? 'justify-end' : 'justify-start'
                )}
              >
                {/* AI Avatar */}
                {msg.role === 'assistant' && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold mt-1">
                    V
                  </div>
                )}

                <div
                  className={cn(
                    'max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed',
                    msg.role === 'user'
                      ? 'rounded-br-md bg-primary text-primary-foreground'
                      : 'rounded-bl-md bg-card border shadow-sm'
                  )}
                >
                  {msg.isStreaming && !msg.content ? (
                    <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                      <Bot className="h-4 w-4" />
                      <span>VidyaAI is thinking</span>
                      <span className="inline-flex gap-0.5">
                        <span className="animate-bounce" style={{ animationDelay: '0ms' }}>.</span>
                        <span className="animate-bounce" style={{ animationDelay: '150ms' }}>.</span>
                        <span className="animate-bounce" style={{ animationDelay: '300ms' }}>.</span>
                      </span>
                    </span>
                  ) : (
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                  )}
                </div>

                {/* User Avatar */}
                {msg.role === 'user' && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-secondary-foreground mt-1">
                    <User className="h-4 w-4" />
                  </div>
                )}
              </div>
            ))}

            {/* Loading indicator (after placeholder is shown) */}
            {isLoading && chatMessages.length > 0 && chatMessages[chatMessages.length - 1].content === '' && null}

            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Message Input Area */}
      <div className="shrink-0 border-t bg-card/80 backdrop-blur-sm p-3 md:p-4">
        {/* Speak button for last AI message */}
        {lastAssistantMsg && chatMessages.length > 0 && (
          <div className="mb-2 flex items-center gap-1.5">
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1.5 text-xs text-muted-foreground hover:text-primary"
              onClick={speakLastMessage}
              disabled={isSpeaking}
            >
              {isSpeaking ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Volume2 className="h-3.5 w-3.5" />
              )}
              {isSpeaking ? 'Speaking...' : 'Listen to last reply'}
            </Button>
          </div>
        )}

        <div className="flex items-end gap-2">
          {/* Voice Record Button */}
          <Button
            variant="outline"
            size="icon"
            className={cn(
              'h-10 w-10 shrink-0 rounded-full transition-colors',
              isRecording
                ? 'border-destructive bg-destructive/10 text-destructive hover:bg-destructive/20 hover:text-destructive'
                : 'hover:bg-primary/10 hover:text-primary hover:border-primary/30'
            )}
            onClick={toggleRecording}
          >
            {isRecording ? (
              <span className="relative flex h-5 w-5 items-center justify-center">
                <span className="animate-pulse-ring absolute inline-flex h-full w-full rounded-full bg-destructive/40" />
                <MicOff className="relative h-4 w-4" />
              </span>
            ) : (
              <Mic className="h-4 w-4" />
            )}
          </Button>

          {/* Text Input */}
          <div className="relative flex-1">
            <Textarea
              ref={textareaRef}
              placeholder="Type your question here..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              className="min-h-[40px] max-h-[120px] resize-none rounded-xl pr-3 py-2.5 text-sm"
              rows={1}
            />
          </div>

          {/* Send Button */}
          <Button
            size="icon"
            className="h-10 w-10 shrink-0 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-sm transition-all disabled:opacity-40"
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {isRecording && (
          <p className="mt-2 flex items-center gap-1.5 text-xs text-destructive">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-destructive" />
            </span>
            Recording... Tap mic to stop
          </p>
        )}
      </div>
    </div>
  );
}
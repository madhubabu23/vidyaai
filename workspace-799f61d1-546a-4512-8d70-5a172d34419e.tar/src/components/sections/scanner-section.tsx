'use client';

import { useState, useRef, useCallback, type DragEvent } from 'react';
import { useAppStore, type ChatMessage } from '@/store/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Camera, Upload, FileText, Sparkles, RotateCcw, Send, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cn } from '@/lib/utils';

const SUBJECTS = ['Math', 'Science', 'English', 'Social Studies', 'Hindi'] as const;

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function ScannerSection() {
  const {
    scannedImage,
    scanResult,
    isScanning,
    student,
    language,
    setScannedImage,
    setScanResult,
    setIsScanning,
    updateXP,
  } = useAppStore();

  const [selectedSubject, setSelectedSubject] = useState<string>('Math');
  const [isDragOver, setIsDragOver] = useState(false);
  const [followUp, setFollowUp] = useState('');
  const [isFollowUpLoading, setIsFollowUpLoading] = useState(false);
  const [followUpResult, setFollowUpResult] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const studentId = student?.id ?? 'anonymous';

  // Scroll result into view
  const scrollToResult = useCallback(() => {
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  }, []);

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith('image/')) return;

      const base64 = await fileToBase64(file);
      setScannedImage(`data:${file.type};base64,${base64}`);
      setScanResult(null);
      setFollowUpResult(null);
    },
    [setScannedImage, setScanResult]
  );

  const handleDrop = useCallback(
    (e: DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      setIsDragOver(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const handleDragOver = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const handleScan = useCallback(async () => {
    if (!scannedImage || isScanning) return;

    setIsScanning(true);
    setScanResult(null);
    setFollowUpResult(null);

    try {
      const base64Data = scannedImage.split(',')[1];
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: base64Data,
          language,
          subject: selectedSubject,
        }),
      });

      if (!res.ok) throw new Error('Scan failed');

      const data = await res.json();
      const result = data.explanation || data.result || 'Could not analyze the image. Please try again.';
      setScanResult(result);
      updateXP(15);
      scrollToResult();
    } catch {
      setScanResult('Sorry, I had trouble analyzing the page. Please check your connection and try again.');
    } finally {
      setIsScanning(false);
    }
  }, [scannedImage, isScanning, language, selectedSubject, setScanResult, setIsScanning, updateXP, scrollToResult]);

  const handleReset = useCallback(() => {
    setScannedImage(null);
    setScanResult(null);
    setFollowUpResult(null);
    setFollowUp('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  }, [setScannedImage, setScanResult]);

  const handleFollowUp = useCallback(async () => {
    if (!followUp.trim() || isFollowUpLoading || !scanResult) return;

    setIsFollowUpLoading(true);
    setFollowUpResult(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `Context from scanned page: "${scanResult.substring(0, 500)}"\n\nFollow-up question: ${followUp.trim()}`,
          sessionId: studentId,
          language,
          subject: selectedSubject,
          studentName: student?.name ?? 'Student',
          grade: student?.grade ?? '',
        }),
      });

      if (!res.ok) throw new Error('Follow-up failed');

      const data = await res.json();
      const reply = data.response || data.message || 'Could not process your question. Please try again.';
      setFollowUpResult(reply);
      setFollowUp('');
    } catch {
      setFollowUpResult('Sorry, I could not process your question. Please try again.');
    } finally {
      setIsFollowUpLoading(false);
    }
  }, [followUp, isFollowUpLoading, scanResult, studentId, language, selectedSubject, student]);

  return (
    <div className="custom-scrollbar flex h-full flex-col gap-6 overflow-y-auto p-3 md:p-4">
      {/* Upload Area */}
      <div className="animate-fade-in-up">
        {!scannedImage ? (
          <div
            className={cn(
              'flex min-h-[280px] cursor-pointer flex-col items-center justify-center gap-4 rounded-xl border-2 border-dashed transition-all duration-200',
              isDragOver
                ? 'border-primary bg-primary/5 scale-[1.01]'
                : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-primary/5'
            )}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
              <Camera className="h-8 w-8 text-primary" />
            </div>
            <div className="text-center">
              <p className="text-sm font-medium text-foreground">
                Upload a photo of your textbook page
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Drag and drop or click to browse
              </p>
            </div>
            <Button variant="outline" size="sm" className="gap-2" type="button">
              <Upload className="h-4 w-4" />
              Choose Image
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileInput}
            />
          </div>
        ) : (
          <div className="relative">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="relative">
                  <img
                    src={scannedImage}
                    alt="Scanned textbook page"
                    className="w-full max-h-[400px] object-contain bg-muted/30"
                  />
                  <div className="absolute top-2 right-2 flex gap-1.5">
                    <Button
                      variant="secondary"
                      size="sm"
                      className="h-8 gap-1.5 shadow-md"
                      onClick={handleReset}
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Rescan</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileInput}
            />
          </div>
        )}
      </div>

      {/* Subject Selector & Scan Button */}
      {scannedImage && !isScanning && !scanResult && (
        <div className="animate-fade-in-up space-y-4" style={{ animationDelay: '100ms', animationFillMode: 'both' }}>
          <div>
            <label className="mb-2 block text-xs font-medium text-muted-foreground">
              Select Subject
            </label>
            <div className="flex flex-wrap gap-2">
              {SUBJECTS.map((subject) => (
                <Badge
                  key={subject}
                  variant={selectedSubject === subject ? 'default' : 'outline'}
                  className={cn(
                    'cursor-pointer select-none rounded-full px-3.5 py-1 text-xs font-medium transition-all duration-150',
                    selectedSubject === subject
                      ? 'shadow-sm'
                      : 'hover:bg-primary/10 hover:text-primary hover:border-primary/30'
                  )}
                  onClick={() => setSelectedSubject(subject)}
                >
                  {subject}
                </Badge>
              ))}
            </div>
          </div>

          <Button
            onClick={handleScan}
            className="w-full gap-2"
            size="lg"
          >
            <Sparkles className="h-5 w-5" />
            Scan &amp; Explain
          </Button>
        </div>
      )}

      {/* Scanning Loading State */}
      {isScanning && (
        <div className="animate-fade-in-up space-y-4">
          <div className="flex items-center gap-3">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <p className="text-sm font-medium">Analyzing your textbook page...</p>
          </div>
          <div className="space-y-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-[90%]" />
            <Skeleton className="h-4 w-[80%]" />
            <Skeleton className="h-4 w-[85%]" />
            <Skeleton className="h-4 w-[70%]" />
          </div>
        </div>
      )}

      {/* Scan Result */}
      {scanResult && (
        <div ref={resultRef} className="animate-fade-in-up space-y-4" style={{ animationDelay: '100ms', animationFillMode: 'both' }}>
          <Card>
            <CardContent className="p-4 md:p-6">
              <div className="mb-3 flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <FileText className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold">AI Explanation</h3>
                  <p className="text-xs text-muted-foreground">
                    {selectedSubject} &middot; +15 XP earned
                  </p>
                </div>
              </div>
              <div className="prose prose-sm max-w-none text-foreground/90 [&_h1]:text-base [&_h2]:text-sm [&_h3]:text-sm [&_p]:text-sm [&_li]:text-sm [&_code]:text-xs [&_pre]:rounded-lg [&_pre]:bg-muted [&_ul]:space-y-1 [&_ol]:space-y-1">
                <ReactMarkdown>{scanResult}</ReactMarkdown>
              </div>
            </CardContent>
          </Card>

          {/* Follow-up Question */}
          <div className="space-y-2">
            <label className="block text-xs font-medium text-muted-foreground">
              Ask a follow-up question about this page
            </label>
            <div className="flex gap-2">
              <Textarea
                placeholder="e.g., Can you explain the second paragraph more simply?"
                value={followUp}
                onChange={(e) => setFollowUp(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleFollowUp();
                  }
                }}
                disabled={isFollowUpLoading}
                className="min-h-[44px] max-h-[120px] resize-none rounded-xl text-sm"
                rows={1}
              />
              <Button
                size="icon"
                className="h-11 w-11 shrink-0 rounded-xl"
                onClick={handleFollowUp}
                disabled={!followUp.trim() || isFollowUpLoading}
              >
                {isFollowUpLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          {/* Follow-up Result */}
          {isFollowUpLoading && (
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-[85%]" />
              <Skeleton className="h-4 w-[75%]" />
            </div>
          )}

          {followUpResult && (
            <Card className="animate-fade-in-up">
              <CardContent className="p-4 md:p-6">
                <div className="prose prose-sm max-w-none text-foreground/90 [&_h1]:text-base [&_h2]:text-sm [&_h3]:text-sm [&_p]:text-sm [&_li]:text-sm [&_code]:text-xs [&_pre]:rounded-lg [&_pre]:bg-muted">
                  <ReactMarkdown>{followUpResult}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Empty State (when no image) */}
      {!scannedImage && !isScanning && (
        <div className="animate-fade-in-up flex flex-col items-center justify-center py-8 text-center" style={{ animationDelay: '200ms', animationFillMode: 'both' }}>
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-muted">
            <FileText className="h-6 w-6 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground max-w-sm">
            Take a photo of any textbook page and VidyaAI will explain the concepts in simple language.
          </p>
        </div>
      )}
    </div>
  );
}
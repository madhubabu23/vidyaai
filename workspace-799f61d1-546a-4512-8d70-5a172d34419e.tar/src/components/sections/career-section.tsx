'use client';

import { useState } from 'react';
import { useAppStore } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Compass,
  GraduationCap,
  Briefcase,
  Heart,
  Sparkles,
  Landmark,
  BookOpen,
  Users,
  Lightbulb,
  ArrowRight,
  Search,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const INTEREST_CHIPS = [
  'Computers',
  'Teaching',
  'Medicine',
  'Agriculture',
  'Engineering',
  'Business',
  'Arts',
  'Sports',
  'Science',
  'Government Jobs',
] as const;

const CAREER_ICONS = [
  { icon: Briefcase, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { icon: GraduationCap, color: 'text-amber-600', bg: 'bg-amber-50' },
  { icon: Landmark, color: 'text-rose-600', bg: 'bg-rose-50' },
  { icon: Users, color: 'text-violet-600', bg: 'bg-violet-50' },
  { icon: BookOpen, color: 'text-blue-600', bg: 'bg-blue-50' },
  { icon: Lightbulb, color: 'text-orange-600', bg: 'bg-orange-50' },
] as const;

export default function CareerSection() {
  const { student, language, careerInterest, setCareerInterest, careerResults, setCareerResults } =
    useAppStore();
  const [isLoading, setIsLoading] = useState(false);
  const [localInput, setLocalInput] = useState(careerInterest);

  const handleChipClick = (chip: string) => {
    setLocalInput(chip);
    setCareerInterest(chip);
  };

  const handleInputChange = (value: string) => {
    setLocalInput(value);
    setCareerInterest(value);
  };

  const handleGetGuidance = async () => {
    if (!localInput.trim() || !student) return;

    setIsLoading(true);
    setCareerResults(null);

    try {
      const res = await fetch('/api/career', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          interest: localInput.trim(),
          language,
          grade: student.grade,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setCareerResults(data.guidance || data.result || data.content || JSON.stringify(data));
      } else {
        setCareerResults('Sorry, something went wrong. Please try again later.');
      }
    } catch {
      setCareerResults('Could not connect to the server. Please check your connection and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleGetGuidance();
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-6 p-4 md:p-6">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-12 w-full max-w-lg rounded-xl" />
        <div className="flex gap-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-8 w-24 rounded-full" />
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent className="space-y-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
            <Skeleton className="h-4 w-4/6" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-32 w-full rounded-lg" />
          </CardContent>
        </Card>
      </div>
    );
  }

  // Results view
  if (careerResults) {
    return (
      <div className="space-y-6 p-4 md:p-6">
        {/* Back to search */}
        <Button
          variant="ghost"
          className="gap-2 text-muted-foreground hover:text-foreground"
          onClick={() => setCareerResults(null)}
        >
          <ArrowRight className="h-4 w-4 rotate-180" />
          Search Another Interest
        </Button>

        {/* Results Card */}
        <Card className="animate-fade-in-up overflow-hidden border-primary/20">
          <CardHeader className="border-b bg-gradient-to-r from-emerald-50 to-amber-50 dark:from-emerald-950/30 dark:to-amber-950/30">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-green-600 shadow-sm">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg">Career Guidance: {localInput}</CardTitle>
                <p className="text-xs text-muted-foreground">
                  Personalized insights for Grade {student?.grade} students
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="prose prose-sm max-w-none p-5 md:p-6 dark:prose-invert prose-headings:text-foreground prose-p:text-foreground/80 prose-strong:text-foreground prose-li:text-foreground/80">
            <ReactMarkdown>{careerResults}</ReactMarkdown>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Empty / initial state
  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="animate-fade-in-up">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-amber-500 to-orange-500">
            <Compass className="h-5 w-5 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
            Explore Your Future
          </h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Discover career paths, scholarships, and opportunities that match your interests.
        </p>
      </div>

      {/* Search Input */}
      <div className="animate-fade-in-up max-w-lg">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="What are you interested in?"
            value={localInput}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            className="h-12 pl-10 text-base rounded-xl border-border/60 focus-visible:ring-primary/30"
          />
          <Button
            onClick={handleGetGuidance}
            disabled={!localInput.trim()}
            className="absolute right-1.5 top-1/2 -translate-y-1/2 gap-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white hover:from-emerald-600 hover:to-green-700 shadow-sm"
            size="sm"
          >
            Get Guidance
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* Quick Interest Chips */}
      <div className="animate-fade-in-up">
        <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Quick Interests
        </p>
        <div className="flex flex-wrap gap-2">
          {INTEREST_CHIPS.map((chip) => {
            const isActive = localInput === chip;
            return (
              <button
                key={chip}
                onClick={() => handleChipClick(chip)}
                className={`inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-all hover:shadow-sm ${
                  isActive
                    ? 'border-primary/40 bg-primary/10 text-primary'
                    : 'border-border/60 bg-background text-foreground hover:bg-accent hover:text-accent-foreground'
                }`}
              >
                <Heart
                  className={`h-3 w-3 ${isActive ? 'fill-current' : 'fill-none'}`}
                />
                {chip}
              </button>
            );
          })}
        </div>
      </div>

      {/* Inspiring Empty State */}
      <div className="animate-fade-in-up">
        <Card className="border-dashed border-2 border-border/40 bg-gradient-to-br from-background to-muted/20">
          <CardContent className="p-6 md:p-8">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-100 to-orange-100 shadow-sm">
                <Lightbulb className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">
                Your Future is Full of Possibilities!
              </h3>
              <p className="mb-6 max-w-md text-sm text-muted-foreground">
                Whether you dream of becoming a doctor, engineer, teacher, artist, or entrepreneur
                — every great career starts with curiosity. Tell us what excites you and we&apos;ll
                help you find the path that&apos;s right for you.
              </p>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
                {CAREER_ICONS.map(({ icon: Icon, color, bg }, i) => (
                  <div
                    key={i}
                    className="flex flex-col items-center gap-1.5 rounded-xl p-3 transition-colors hover:bg-accent"
                  >
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full ${bg}`}>
                      <Icon className={`h-5 w-5 ${color}`} />
                    </div>
                    <span className="text-[10px] font-medium text-muted-foreground">
                      {['Career', 'Education', 'Govt Jobs', 'Mentors', 'Skills', 'Ideas'][i]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom encouragement */}
      <div className="animate-fade-in-up flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <Sparkles className="h-4 w-4 text-amber-500" />
        <span>AI-powered guidance tailored for students in India</span>
        <Sparkles className="h-4 w-4 text-amber-500" />
      </div>
    </div>
  );
}
'use client';

import { useState, useCallback } from 'react';
import { useAppStore, type QuizState } from '@/store/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  FileQuestion,
  CheckCircle,
  XCircle,
  Trophy,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Loader2,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const SUBJECTS = ['Math', 'Science', 'English', 'Social Studies', 'Hindi'] as const;
const DIFFICULTIES = ['Easy', 'Medium', 'Hard'] as const;
const NUM_QUESTIONS = [3, 5, 10] as const;

const QUICK_TOPICS = [
  'Photosynthesis',
  'Fractions',
  'Indian History',
  'Grammar',
  'Force & Motion',
];

const OPTION_LABELS = ['A', 'B', 'C', 'D'];

function getScoreMessage(score: number, total: number): { message: string; color: string } {
  const pct = total > 0 ? (score / total) * 100 : 0;
  if (pct >= 80) return { message: 'Excellent! 🎉', color: 'text-emerald-600' };
  if (pct >= 50) return { message: 'Good job! 👍', color: 'text-amber-600' };
  return { message: 'Keep practicing! 💪', color: 'text-orange-600' };
}

function calculateXP(score: number, total: number, difficulty: string): number {
  const baseXP = score * 5;
  const diffMultiplier = difficulty === 'Easy' ? 1 : difficulty === 'Medium' ? 1.5 : 2;
  const bonus = score === total ? 10 : 0;
  return Math.floor(baseXP * diffMultiplier) + bonus;
}

export default function QuizSection() {
  const {
    quiz,
    setQuiz,
    setQuizAnswer,
    completeQuiz,
    resetQuiz,
    student,
    language,
    updateXP,
  } = useAppStore();

  const [topic, setTopic] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('Math');
  const [difficulty, setDifficulty] = useState<string>('Medium');
  const [numQuestions, setNumQuestions] = useState<number>(5);
  const [isGenerating, setIsGenerating] = useState(false);

  // Quiz taking state (local)
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerRevealed, setIsAnswerRevealed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const studentId = student?.id ?? 'anonymous';

  // Generate quiz
  const handleGenerateQuiz = useCallback(async () => {
    if (!topic.trim() || isGenerating) return;

    setIsGenerating(true);

    try {
      const res = await fetch('/api/quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          subject: selectedSubject,
          difficulty,
          language,
          numQuestions,
          studentId,
        }),
      });

      if (!res.ok) throw new Error('Quiz generation failed');

      const data = await res.json();
      const quizData: QuizState = {
        questions: data.questions || [],
        currentQuestion: 0,
        answers: new Array((data.questions || []).length).fill(null),
        isCompleted: false,
        score: 0,
        subject: selectedSubject,
        topic: topic.trim(),
      };
      setQuiz(quizData);
      setSelectedOption(quizData.answers[0] ?? null);
      setIsAnswerRevealed(false);
    } catch {
      // Could show a toast here
    } finally {
      setIsGenerating(false);
    }
  }, [topic, isGenerating, selectedSubject, difficulty, language, numQuestions, studentId, setQuiz]);

  // Handle option selection
  const handleSelectOption = useCallback(
    (value: string) => {
      if (isAnswerRevealed || !quiz) return;
      const idx = parseInt(value, 10);
      setSelectedOption(idx);
    },
    [isAnswerRevealed, quiz]
  );

  // Check answer
  const handleCheckAnswer = useCallback(() => {
    if (selectedOption === null || !quiz) return;
    setIsAnswerRevealed(true);
    setIsSubmitting(true);
    setQuizAnswer(quiz.currentQuestion, selectedOption);
    setIsSubmitting(false);
  }, [selectedOption, quiz, setQuizAnswer]);

  // Next question
  const handleNextQuestion = useCallback(() => {
    if (!quiz) return;

    if (quiz.currentQuestion >= quiz.questions.length - 1) {
      // Quiz complete
      completeQuiz();
      // Calculate and award XP
      let score = 0;
      quiz.questions.forEach((q, i) => {
        if ((quiz.answers[i] ?? quiz.answers[quiz.currentQuestion]) === q.correctIndex) score++;
      });
      // Use the answers stored in quiz (already updated)
      const finalScore = quiz.questions.reduce((acc, q, i) => {
        return acc + (q.correctIndex === quiz.answers[i] ? 1 : 0);
      }, 0);
      const xp = calculateXP(finalScore, quiz.questions.length, difficulty);
      updateXP(xp);

      // Save results via PUT
      fetch('/api/quiz', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId,
          quizId: quiz.topic + '-' + quiz.subject,
          score: finalScore,
          total: quiz.questions.length,
          subject: quiz.subject,
          topic: quiz.topic,
          xp,
        }),
      }).catch(() => {});
    } else {
      const nextIdx = quiz.currentQuestion + 1;
      setQuiz({ ...quiz, currentQuestion: nextIdx });
      setSelectedOption(quiz.answers[nextIdx] ?? null);
      setIsAnswerRevealed(false);
    }
  }, [quiz, completeQuiz, difficulty, updateXP, studentId, setQuiz]);

  // Reset quiz
  const handleResetQuiz = useCallback(() => {
    resetQuiz();
    setSelectedOption(null);
    setIsAnswerRevealed(false);
    setTopic('');
  }, [resetQuiz]);

  // ========================
  // QUIZ SETUP STATE
  // ========================
  if (!quiz) {
    return (
      <div className="custom-scrollbar flex h-full flex-col gap-6 overflow-y-auto p-3 md:p-4">
        <div className="animate-fade-in-up">
          <div className="mb-6 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
              <FileQuestion className="h-7 w-7 text-primary" />
            </div>
            <h2 className="text-lg font-semibold">AI Quiz Generator</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Choose a topic and let AI create a personalized quiz for you
            </p>
          </div>

          <Card>
            <CardContent className="space-y-5 p-4 md:p-6">
              {/* Topic Input */}
              <div className="space-y-2">
                <label className="block text-sm font-medium">Topic</label>
                <Input
                  placeholder="e.g., Solar System, Quadratic Equations..."
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  disabled={isGenerating}
                  className="h-11"
                />
              </div>

              {/* Quick Topic Chips */}
              <div className="space-y-2">
                <label className="block text-xs font-medium text-muted-foreground">
                  Quick topics
                </label>
                <div className="flex flex-wrap gap-2">
                  {QUICK_TOPICS.map((qt) => (
                    <Badge
                      key={qt}
                      variant={topic === qt ? 'default' : 'outline'}
                      className={cn(
                        'cursor-pointer select-none rounded-full px-3 py-1 text-xs font-medium transition-all duration-150',
                        topic === qt
                          ? 'shadow-sm'
                          : 'hover:bg-primary/10 hover:text-primary hover:border-primary/30'
                      )}
                      onClick={() => setTopic(qt)}
                    >
                      {qt}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Subject Selector */}
              <div className="space-y-2">
                <label className="block text-sm font-medium">Subject</label>
                <div className="flex flex-wrap gap-2">
                  {SUBJECTS.map((subject) => (
                    <Badge
                      key={subject}
                      variant={selectedSubject === subject ? 'default' : 'outline'}
                      className={cn(
                        'cursor-pointer select-none rounded-full px-3.5 py-1 text-xs font-medium transition-all duration-150',
                        selectedSubject === subject
                          ? 'shadow-sm'
                          : 'hover:bg-primary/10 hover:text-primary hover:border-primary/30'
                      )}
                      onClick={() => setSelectedSubject(subject)}
                    >
                      {subject}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Difficulty */}
              <div className="space-y-2">
                <label className="block text-sm font-medium">Difficulty</label>
                <RadioGroup
                  value={difficulty}
                  onValueChange={setDifficulty}
                  className="flex gap-2"
                  disabled={isGenerating}
                >
                  {DIFFICULTIES.map((d) => (
                    <label
                      key={d}
                      className={cn(
                        'flex cursor-pointer items-center gap-2 rounded-lg border px-4 py-2 text-sm transition-all duration-150',
                        difficulty === d
                          ? 'border-primary bg-primary/5 text-primary font-medium'
                          : 'border-border hover:border-primary/30 hover:bg-primary/5'
                      )}
                    >
                      <RadioGroupItem value={d} className="sr-only" />
                      <span>{d}</span>
                    </label>
                  ))}
                </RadioGroup>
              </div>

              {/* Number of Questions */}
              <div className="space-y-2">
                <label className="block text-sm font-medium">Number of Questions</label>
                <div className="flex gap-2">
                  {NUM_QUESTIONS.map((n) => (
                    <Button
                      key={n}
                      variant={numQuestions === n ? 'default' : 'outline'}
                      size="sm"
                      className={cn(
                        'rounded-lg px-4 transition-all duration-150',
                        numQuestions === n ? 'shadow-sm' : ''
                      )}
                      onClick={() => setNumQuestions(n)}
                      disabled={isGenerating}
                    >
                      {n}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Generate Button */}
              <Button
                onClick={handleGenerateQuiz}
                className="w-full gap-2"
                size="lg"
                disabled={!topic.trim() || isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Generating Quiz...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-5 w-5" />
                    Generate Quiz
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {isGenerating && (
          <div className="animate-fade-in-up space-y-3">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        )}
      </div>
    );
  }

  // ========================
  // QUIZ RESULTS STATE
  // ========================
  if (quiz.isCompleted) {
    const { message, color } = getScoreMessage(quiz.score, quiz.questions.length);
    const xpEarned = calculateXP(quiz.score, quiz.questions.length, difficulty);
    const pct = quiz.questions.length > 0 ? Math.round((quiz.score / quiz.questions.length) * 100) : 0;

    return (
      <div className="custom-scrollbar flex h-full flex-col gap-6 overflow-y-auto p-3 md:p-4">
        <div className="animate-fade-in-up">
          {/* Results Header */}
          <div className="mb-6 flex flex-col items-center text-center">
            <div className="relative mb-4 flex h-24 w-24 items-center justify-center">
              {/* Circular progress background */}
              <svg className="absolute h-24 w-24 -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="currentColor"
                  className="text-muted/30"
                  strokeWidth="8"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="currentColor"
                  className={cn(
                    pct >= 80 ? 'text-emerald-500' : pct >= 50 ? 'text-amber-500' : 'text-orange-500'
                  )}
                  strokeWidth="8"
                  strokeDasharray={`${2 * Math.PI * 42}`}
                  strokeDashoffset={`${2 * Math.PI * 42 * (1 - pct / 100)}`}
                  strokeLinecap="round"
                  style={{ transition: 'stroke-dashoffset 1s ease-out' }}
                />
              </svg>
              <div className="flex flex-col items-center">
                <Trophy className={cn('h-5 w-5 mb-0.5', pct >= 80 ? 'text-emerald-500' : pct >= 50 ? 'text-amber-500' : 'text-orange-500')} />
                <span className="text-2xl font-bold">{pct}%</span>
              </div>
            </div>
            <h2 className={cn('text-xl font-bold', color)}>{message}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              You scored <span className="font-semibold text-foreground">{quiz.score}</span> out of{' '}
              <span className="font-semibold text-foreground">{quiz.questions.length}</span>
            </p>
            <div className="mt-3 flex items-center gap-1.5">
              <Zap className="h-4 w-4 text-amber-500" />
              <span className="text-sm font-semibold text-amber-600">+{xpEarned} XP earned</span>
            </div>
          </div>

          {/* Question Review */}
          <Card>
            <CardContent className="space-y-4 p-4 md:p-6">
              <h3 className="text-sm font-semibold">Review Answers</h3>
              <div className="max-h-96 overflow-y-auto space-y-3 custom-scrollbar">
                {quiz.questions.map((q, i) => {
                  const userAns = quiz.answers[i];
                  const isCorrect = userAns === q.correctIndex;

                  return (
                    <div
                      key={q.id}
                      className="animate-fade-in-up rounded-lg border p-3"
                      style={{ animationDelay: `${i * 60}ms`, animationFillMode: 'both' }}
                    >
                      <div className="mb-2 flex items-start gap-2">
                        {isCorrect ? (
                          <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                        ) : (
                          <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                        )}
                        <p className="text-sm font-medium leading-snug">
                          {i + 1}. {q.question}
                        </p>
                      </div>

                      <div className="ml-6 space-y-1">
                        <p className="text-xs text-muted-foreground">
                          Your answer:{' '}
                          <span className={isCorrect ? 'text-emerald-600 font-medium' : 'text-red-600 font-medium'}>
                            {userAns !== null && userAns !== undefined
                              ? `${OPTION_LABELS[userAns]}. ${q.options[userAns]}`
                              : 'Not answered'}
                          </span>
                        </p>
                        {!isCorrect && (
                          <p className="text-xs text-muted-foreground">
                            Correct answer:{' '}
                            <span className="text-emerald-600 font-medium">
                              {OPTION_LABELS[q.correctIndex]}. {q.options[q.correctIndex]}
                            </span>
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground/80 italic">{q.explanation}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Take Another Quiz */}
          <Button onClick={handleResetQuiz} className="w-full gap-2 mt-4" size="lg">
            <Sparkles className="h-5 w-5" />
            Take Another Quiz
          </Button>
        </div>
      </div>
    );
  }

  // ========================
  // QUIZ TAKING STATE
  // ========================
  const currentQ = quiz.questions[quiz.currentQuestion];
  const progressPct = quiz.questions.length > 0
    ? ((quiz.currentQuestion + 1) / quiz.questions.length) * 100
    : 0;
  const isLastQuestion = quiz.currentQuestion >= quiz.questions.length - 1;
  const currentAnswerCorrect = isAnswerRevealed && selectedOption === currentQ?.correctIndex;

  return (
    <div className="custom-scrollbar flex h-full flex-col gap-6 overflow-y-auto p-3 md:p-4">
      <div className="animate-fade-in-up">
        {/* Progress */}
        <div className="mb-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-medium">
              Question {quiz.currentQuestion + 1} of {quiz.questions.length}
            </span>
            <span>
              {quiz.topic} &middot; {quiz.subject}
            </span>
          </div>
          <Progress value={progressPct} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="mb-4">
          <CardContent className="p-4 md:p-6">
            <p className="text-base font-medium leading-relaxed md:text-lg">{currentQ.question}</p>
          </CardContent>
        </Card>

        {/* Options */}
        <div className="space-y-3 mb-6">
          {currentQ.options.map((option, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrectOption = isAnswerRevealed && idx === currentQ.correctIndex;
            const isWrongSelection = isAnswerRevealed && isSelected && idx !== currentQ.correctIndex;

            return (
              <button
                key={idx}
                disabled={isAnswerRevealed}
                onClick={() => handleSelectOption(idx.toString())}
                className={cn(
                  'flex w-full items-start gap-3 rounded-xl border-2 p-3.5 text-left text-sm transition-all duration-150',
                  !isAnswerRevealed && !isSelected && 'border-border hover:border-primary/30 hover:bg-primary/5 cursor-pointer',
                  !isAnswerRevealed && isSelected && 'border-primary bg-primary/5 cursor-pointer',
                  isCorrectOption && 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30',
                  isWrongSelection && 'border-red-500 bg-red-50 dark:bg-red-950/30',
                  isAnswerRevealed && !isCorrectOption && !isWrongSelection && 'border-border opacity-60 cursor-default'
                )}
              >
                <span
                  className={cn(
                    'flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold transition-colors',
                    isSelected && !isAnswerRevealed && 'bg-primary text-primary-foreground',
                    isCorrectOption && 'bg-emerald-500 text-white',
                    isWrongSelection && 'bg-red-500 text-white',
                    !isSelected && !isCorrectOption && !isWrongSelection && 'bg-muted text-muted-foreground'
                  )}
                >
                  {isCorrectOption ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : isWrongSelection ? (
                    <XCircle className="h-4 w-4" />
                  ) : (
                    OPTION_LABELS[idx]
                  )}
                </span>
                <span className="pt-0.5 leading-relaxed">{option}</span>
              </button>
            );
          })}
        </div>

        {/* Explanation after answer */}
        {isAnswerRevealed && (
          <div className="animate-fade-in-up mb-4">
            <Card
              className={cn(
                'border-l-4',
                currentAnswerCorrect
                  ? 'border-l-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20'
                  : 'border-l-red-500 bg-red-50/50 dark:bg-red-950/20'
              )}
            >
              <CardContent className="p-4">
                <p className="text-xs font-semibold mb-1">
                  {currentAnswerCorrect ? '✅ Correct!' : '❌ Incorrect'}
                </p>
                <p className="text-sm text-muted-foreground">{currentQ.explanation}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3">
          {!isAnswerRevealed ? (
            <Button
              onClick={handleCheckAnswer}
              className="flex-1 gap-2"
              size="lg"
              disabled={selectedOption === null || isSubmitting}
            >
              {isSubmitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CheckCircle className="h-4 w-4" />
              )}
              Check Answer
            </Button>
          ) : (
            <Button
              onClick={handleNextQuestion}
              className="flex-1 gap-2"
              size="lg"
            >
              {isLastQuestion ? (
                <>
                  <Trophy className="h-4 w-4" />
                  See Results
                </>
              ) : (
                <>
                  Next Question
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          )}
        </div>

        {/* Quit Quiz */}
        <div className="mt-3 text-center">
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-muted-foreground hover:text-destructive"
            onClick={handleResetQuiz}
          >
            Quit Quiz
          </Button>
        </div>
      </div>
    </div>
  );
}
'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  AreaChart,
  Area,
  Cell,
  ResponsiveContainer,
} from 'recharts';
import {
  BarChart3,
  Trophy,
  BookOpen,
  Star,
  Award,
  TrendingUp,
  Target,
  Flame,
  Zap,
} from 'lucide-react';

interface ProgressData {
  totalXP: number;
  level: number;
  quizzesTaken: number;
  questionsAsked: number;
  subjectPerformance: { subject: string; avgScore: number; fill: string }[];
  dailyActivity: { day: string; questions: number }[];
  badges: { id: string; name: string; icon: string; description: string; earnedAt: string }[];
  topicProgress: { topic: string; subject: string; score: number; attempts: number; mastered: boolean }[];
}

const STATS_CONFIG = {
  totalXP: { label: 'Total XP', icon: Zap, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' },
  level: { label: 'Level', icon: Trophy, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
  quizzesTaken: { label: 'Quizzes Taken', icon: Target, color: 'text-violet-600', bg: 'bg-violet-50', border: 'border-violet-200' },
  questionsAsked: { label: 'Questions Asked', icon: BookOpen, color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-200' },
} as const;

const CHART_COLORS = [
  'hsl(142, 71%, 45%)',
  'hsl(142, 60%, 55%)',
  'hsl(45, 93%, 47%)',
  'hsl(38, 92%, 50%)',
  'hsl(152, 69%, 40%)',
  'hsl(48, 96%, 53%)',
];

const ACTIVITY_CHART_CONFIG = {
  questions: {
    label: 'Questions',
    color: 'hsl(142, 71%, 45%)',
  },
};

const SUBJECT_CHART_CONFIG: Record<string, { label: string; color: string }> = {
  Math: { label: 'Math', color: CHART_COLORS[0] },
  Science: { label: 'Science', color: CHART_COLORS[1] },
  English: { label: 'English', color: CHART_COLORS[2] },
  'Social Studies': { label: 'Social Studies', color: CHART_COLORS[3] },
  Hindi: { label: 'Hindi', color: CHART_COLORS[4] },
};

function getBadgeIcon(iconStr: string) {
  switch (iconStr) {
    case 'flame':
      return <Flame className="h-6 w-6 text-orange-500" />;
    case 'star':
      return <Star className="h-6 w-6 text-amber-500" />;
    case 'trophy':
      return <Trophy className="h-6 w-6 text-emerald-500" />;
    case 'zap':
      return <Zap className="h-6 w-6 text-yellow-500" />;
    case 'target':
      return <Target className="h-6 w-6 text-rose-500" />;
    case 'book':
      return <BookOpen className="h-6 w-6 text-blue-500" />;
    case 'trending':
      return <TrendingUp className="h-6 w-6 text-green-500" />;
    default:
      return <Award className="h-6 w-6 text-purple-500" />;
  }
}

export default function ProgressSection() {
  const student = useAppStore((s) => s.student);
  const [progressData, setProgressData] = useState<ProgressData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!student) {
      setLoading(false);
      return;
    }

    async function fetchProgress() {
      try {
        const res = await fetch(`/api/progress?studentId=${student.id}`);
        if (res.ok) {
          const data = await res.json();
          setProgressData(data);
        }
      } catch {
        // Silently handle fetch errors
      } finally {
        setLoading(false);
      }
    }

    fetchProgress();
  }, [student]);

  if (loading) {
    return (
      <div className="space-y-6 p-4 md:p-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-72 rounded-xl" />
        <Skeleton className="h-72 rounded-xl" />
      </div>
    );
  }

  // Empty state when no student or no data
  if (!student || !progressData) {
    return (
      <div className="flex flex-col items-center justify-center px-4 py-20 animate-fade-in-up">
        <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-100 to-amber-100">
          <TrendingUp className="h-10 w-10 text-emerald-600" />
        </div>
        <h2 className="mb-2 text-xl font-bold text-foreground md:text-2xl">
          Start Learning to See Your Progress!
        </h2>
        <p className="max-w-md text-center text-muted-foreground">
          Ask questions, take quizzes, and explore subjects to track your learning journey. Every step counts towards your growth!
        </p>
        <div className="mt-6 flex gap-2">
          <Badge variant="secondary" className="gap-1">
            <BookOpen className="h-3 w-3" /> Ask Questions
          </Badge>
          <Badge variant="secondary" className="gap-1">
            <Target className="h-3 w-3" /> Take Quizzes
          </Badge>
          <Badge variant="secondary" className="gap-1">
            <Star className="h-3 w-3" /> Earn XP
          </Badge>
        </div>
      </div>
    );
  }

  const stats = [
    { key: 'totalXP' as const, value: progressData.totalXP },
    { key: 'level' as const, value: progressData.level },
    { key: 'quizzesTaken' as const, value: progressData.quizzesTaken },
    { key: 'questionsAsked' as const, value: progressData.questionsAsked },
  ];

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="animate-fade-in-up">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-green-600">
            <BarChart3 className="h-5 w-5 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
            Your Learning Journey
          </h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Keep going, {student.name}! Every lesson brings you closer to your goals.
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4 animate-fade-in-up">
        {stats.map(({ key, value }) => {
          const config = STATS_CONFIG[key];
          const Icon = config.icon;
          return (
            <Card key={key} className={`border ${config.border} ${config.bg}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">
                      {config.label}
                    </p>
                    <p className="mt-1 text-2xl font-bold text-foreground">
                      {value.toLocaleString()}
                    </p>
                  </div>
                  <div className={`rounded-lg p-2 ${config.bg}`}>
                    <Icon className={`h-5 w-5 ${config.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Subject Performance Bar Chart */}
      {progressData.subjectPerformance.length > 0 && (
        <Card className="animate-fade-in-up">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <BarChart3 className="h-5 w-5 text-emerald-600" />
              Subject Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={SUBJECT_CHART_CONFIG}
              className="h-[280px] w-full"
            >
              <BarChart
                data={progressData.subjectPerformance}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="subject"
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                />
                <YAxis
                  domain={[0, 100]}
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                />
                <ChartTooltip
                  content={<ChartTooltipContent nameKey="subject" />}
                  cursor={{ fill: 'hsl(var(--muted))', radius: 4 }}
                />
                <Bar dataKey="avgScore" radius={[6, 6, 0, 0]} maxBarSize={48}>
                  {progressData.subjectPerformance.map((_, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={CHART_COLORS[index % CHART_COLORS.length]}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      )}

      {/* Daily Activity Area Chart */}
      {progressData.dailyActivity.length > 0 && (
        <Card className="animate-fade-in-up">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-5 w-5 text-amber-600" />
              Daily Activity (Last 7 Days)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={ACTIVITY_CHART_CONFIG}
              className="h-[240px] w-full"
            >
              <AreaChart
                data={progressData.dailyActivity}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="activityGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop
                      offset="5%"
                      stopColor="hsl(142, 71%, 45%)"
                      stopOpacity={0.3}
                    />
                    <stop
                      offset="95%"
                      stopColor="hsl(142, 71%, 45%)"
                      stopOpacity={0}
                    />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="day"
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                  allowDecimals={false}
                />
                <ChartTooltip
                  content={<ChartTooltipContent />}
                  cursor={{ stroke: 'hsl(var(--muted))', strokeWidth: 1 }}
                />
                <Area
                  type="monotone"
                  dataKey="questions"
                  stroke="hsl(142, 71%, 45%)"
                  strokeWidth={2}
                  fill="url(#activityGradient)"
                />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>
      )}

      {/* Badges Earned */}
      {progressData.badges.length > 0 && (
        <div className="animate-fade-in-up">
          <h2 className="mb-3 flex items-center gap-2 text-lg font-semibold">
            <Award className="h-5 w-5 text-amber-600" />
            Badges Earned
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {progressData.badges.map((badge) => (
              <Card
                key={badge.id}
                className="group border-border/50 transition-all hover:border-primary/30 hover:shadow-md"
              >
                <CardContent className="flex flex-col items-center p-4 text-center">
                  <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-amber-50 to-orange-50 transition-transform group-hover:scale-110">
                    {getBadgeIcon(badge.icon)}
                  </div>
                  <h3 className="text-sm font-semibold text-foreground">
                    {badge.name}
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
                    {badge.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Topic Progress Table */}
      {progressData.topicProgress.length > 0 && (
        <Card className="animate-fade-in-up">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <BookOpen className="h-5 w-5 text-emerald-600" />
              Topic Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Topic</TableHead>
                    <TableHead className="hidden sm:table-cell">Subject</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Attempts</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {progressData.topicProgress.map((topic, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="font-medium">{topic.topic}</TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <Badge variant="outline">{topic.subject}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress
                            value={topic.score}
                            className="h-2 w-16"
                          />
                          <span className="text-xs font-medium tabular-nums">
                            {topic.score}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="tabular-nums">{topic.attempts}</TableCell>
                      <TableCell>
                        {topic.mastered ? (
                          <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 hover:bg-emerald-100">
                            <Star className="mr-1 h-3 w-3" />
                            Mastered
                          </Badge>
                        ) : (
                          <Badge variant="secondary">In Progress</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
'use client';

import { useMemo } from 'react';
import { useAppStore } from '@/store/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  MessageCircle,
  Camera,
  FileQuestion,
  Compass,
  BookOpen,
  Lightbulb,
  Star,
  Flame,
  Trophy,
  Zap,
} from 'lucide-react';

const SUBJECTS = [
  { name: 'Math', icon: '🔢', color: 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100' },
  { name: 'Science', icon: '🔬', color: 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100' },
  { name: 'English', icon: '📖', color: 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100' },
  { name: 'Social Studies', icon: '🌍', color: 'bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100' },
  { name: 'Hindi', icon: '📝', color: 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100' },
] as const;

const QUICK_ACTIONS = [
  {
    label: 'Ask AI Teacher',
    description: 'Get instant help with your doubts',
    icon: MessageCircle,
    tab: 'teacher' as const,
    gradient: 'from-emerald-500 to-green-600',
  },
  {
    label: 'Scan Textbook',
    description: 'Photo se samjho kya likha hai',
    icon: Camera,
    tab: 'scanner' as const,
    gradient: 'from-amber-500 to-orange-500',
  },
  {
    label: 'Take a Quiz',
    description: 'Test what you have learnt',
    icon: FileQuestion,
    tab: 'quiz' as const,
    gradient: 'from-violet-500 to-purple-600',
  },
  {
    label: 'Career Guidance',
    description: 'Discover your future path',
    icon: Compass,
    tab: 'career' as const,
    gradient: 'from-rose-500 to-pink-600',
  },
];

const DAILY_TIPS = [
  "🌱 Tip: Revise for 15 minutes before sleeping — it helps your brain remember better!",
  "💡 Tip: Try explaining a concept to a friend. If you can teach it, you truly understand it!",
  "📚 Tip: Read each chapter twice — once quickly to get the idea, once slowly to understand deeply.",
  "🧠 Tip: Take short 5-minute breaks every 25 minutes while studying. It keeps your mind fresh!",
  "✍️ Tip: Write down important formulas and stick them on your wall. You will see them daily!",
  "🎯 Tip: Start with the hardest subject first when your energy is highest!",
  "🗣️ Tip: Read aloud when studying — your brain remembers better when you hear and see together!",
  "📐 Tip: Practice math problems daily, even just 3-4. Consistency beats cramming!",
];

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 17) return 'Good Afternoon';
  return 'Good Evening';
}

export default function HomeSection() {
  const { student, setActiveTab, chatMessages } = useAppStore();
  const questionsAsked = useMemo(() => {
    return chatMessages.filter((m) => m.role === 'user').length;
  }, [chatMessages]);

  const tipIndex = useMemo(() => {
    const dayOfYear = Math.floor(
      (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
    );
    return dayOfYear % DAILY_TIPS.length;
  }, []);

  const studentName = student?.name ?? 'Student';
  const greeting = getGreeting();

  const stats = [
    {
      label: 'Total XP',
      value: student?.xp ?? 0,
      icon: Zap,
      iconColor: 'text-amber-500',
      bgAccent: 'bg-amber-50',
    },
    {
      label: 'Level',
      value: student?.level ?? 1,
      icon: Trophy,
      iconColor: 'text-emerald-500',
      bgAccent: 'bg-emerald-50',
    },
    {
      label: 'Streak',
      value: `${student?.streak ?? 0} days`,
      icon: Flame,
      iconColor: 'text-orange-500',
      bgAccent: 'bg-orange-50',
    },
    {
      label: 'Questions Asked',
      value: questionsAsked,
      icon: BookOpen,
      iconColor: 'text-violet-500',
      bgAccent: 'bg-violet-50',
    },
  ];

  return (
    <div className="space-y-6 pb-6">
      {/* Welcome Banner */}
      <div className="animate-fade-in-up rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20 p-5 md:p-6">
        <div className="flex items-start gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xl">
            🌾
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm text-muted-foreground">{greeting} 🌅</p>
            <h1 className="mt-0.5 text-2xl font-bold tracking-tight md:text-3xl">
              Welcome, {studentName}!
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {student?.grade
                ? `Class ${student.grade} — Let&apos;s make today a great learning day!`
                : 'Let\'s make today a great learning day!'}
            </p>
          </div>
          <div className="hidden sm:flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
            <span>Keep going!</span>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        {stats.map((stat, i) => (
          <Card
            key={stat.label}
            className={`animate-fade-in-up border-0 shadow-sm gap-0 py-4 ${stat.bgAccent}`}
            style={{ animationDelay: `${i * 80}ms`, animationFillMode: 'both' }}
          >
            <CardContent className="flex items-center gap-3 p-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/70 shadow-sm">
                <stat.icon className={`h-5 w-5 ${stat.iconColor}`} />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-muted-foreground">{stat.label}</p>
                <p className="text-lg font-bold leading-tight">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 gap-3 md:gap-4">
          {QUICK_ACTIONS.map((action, i) => (
            <Card
              key={action.tab}
              className="group animate-fade-in-up cursor-pointer border-0 shadow-sm gap-0 py-4 hover:shadow-md transition-all duration-200 hover:-translate-y-0.5"
              style={{ animationDelay: `${(i + 4) * 80}ms`, animationFillMode: 'both' }}
              onClick={() => setActiveTab(action.tab)}
            >
              <CardContent className="flex flex-col items-center gap-2.5 p-4 text-center">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${action.gradient} shadow-sm`}
                >
                  <action.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-sm font-semibold leading-tight">{action.label}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">
                    {action.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Daily Tip */}
      <Card className="animate-fade-in-up border-amber-200/60 bg-gradient-to-br from-amber-50/80 to-orange-50/50 gap-0 py-0" style={{ animationDelay: '640ms', animationFillMode: 'both' }}>
        <CardContent className="flex items-start gap-3 p-4 md:p-5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100">
            <Lightbulb className="h-5 w-5 text-amber-600" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold uppercase tracking-wider text-amber-700">
              Daily Tip
            </p>
            <p className="mt-1 text-sm leading-relaxed text-amber-900/80">
              {DAILY_TIPS[tipIndex]}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Subject Quick Select */}
      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Choose a Subject
        </h2>
        <div className="flex flex-wrap gap-2">
          {SUBJECTS.map((subject) => (
            <Button
              key={subject.name}
              variant="outline"
              className={`animate-fade-in-up gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-200 hover:-translate-y-0.5 ${subject.color}`}
              style={{ animationDelay: `${(SUBJECTS.indexOf(subject) + 8) * 80}ms`, animationFillMode: 'both' }}
              onClick={() => {
                setActiveTab('teacher');
              }}
            >
              <span className="text-base">{subject.icon}</span>
              {subject.name}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}